const {getData}=require('./api-utils.js');
const endpoints=require('./config.js');
const {getRandomGame}=require('./api-utils.js');
module.exports={
    getData,
    endpoints,
    getRandomGame
};